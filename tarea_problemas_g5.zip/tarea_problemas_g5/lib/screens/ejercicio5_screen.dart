import 'package:flutter/material.dart';

class Ejercicio5Screen extends StatefulWidget {
  const Ejercicio5Screen({Key? key}) : super(key: key);

  @override
  _Ejercicio5ScreenState createState() => _Ejercicio5ScreenState();
}

class _Ejercicio5ScreenState extends State<Ejercicio5Screen> {
  List<int> _primes = [];

  void _generatePrimes() {
    const int maxNumber = 32767;
    List<int> primes = [];

    for (int number = 3; number <= maxNumber; number++) {
      bool isPrime = true;
      for (int i = 2; i * i <= number; i++) {
        if (number % i == 0) {
          isPrime = false;
          break;
        }
      }
      if (isPrime) {
        primes.add(number);
      }
    }

    setState(() {
      _primes = primes;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Row(
          children: [
            const Icon(Icons.numbers),
            const SizedBox(width: 10),
            const Text('Ejercicio 5: Números Primos'),
          ],
        ),
        backgroundColor: Colors.teal,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            ElevatedButton(
              onPressed: _generatePrimes,
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.teal,
                padding: const EdgeInsets.symmetric(vertical: 12.0),
              ),
              child: const Text(
                'Generar Primos',
                style: TextStyle(color: Colors.white),
              ),
            ),
            const SizedBox(height: 10),
            Expanded(
              child: _primes.isEmpty
                  ? const Text(
                'Presione el botón para generar los números primos.',
                textAlign: TextAlign.center,
              )
                  : ListView.builder(
                itemCount: _primes.length,
                itemBuilder: (context, index) {
                  return Text(
                    '${_primes[index]}',
                    style: const TextStyle(fontSize: 16),
                  );
                },
              ),
            ),
            const SizedBox(height: 10),
            Align(
              alignment: Alignment.bottomRight,
              child: SizedBox(
                width: 100, // Botón pequeño
                child: ElevatedButton(
                  onPressed: () {
                    Navigator.pop(context);
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.teal,
                    padding: const EdgeInsets.symmetric(vertical: 8.0),
                  ),
                  child: const Text(
                    'Volver',
                    style: TextStyle(color: Colors.white),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

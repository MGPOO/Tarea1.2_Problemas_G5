import 'package:flutter/material.dart';

class Ejercicio3Screen extends StatefulWidget {
  const Ejercicio3Screen({Key? key}) : super(key: key);

  @override
  _Ejercicio3ScreenState createState() => _Ejercicio3ScreenState();
}

class _Ejercicio3ScreenState extends State<Ejercicio3Screen> {
  final TextEditingController _controller1 = TextEditingController();
  final TextEditingController _controller2 = TextEditingController();
  String _result = 'Ingrese dos números para calcular el máximo común divisor (MCD).';

  void _calculateMCD() {
    final int? num1 = int.tryParse(_controller1.text);
    final int? num2 = int.tryParse(_controller2.text);

    if (num1 == null || num2 == null || num1 <= 0 || num2 <= 0) {
      setState(() {
        _result = 'Por favor, ingrese números válidos y positivos.';
      });
      return;
    }

    int a = num1;
    int b = num2;
    while (b != 0) {
      final int temp = b;
      b = a % b;
      a = temp;
    }

    setState(() {
      _result = 'El MCD de $num1 y $num2 es $a.';
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Row(
          children: [
            const Icon(Icons.functions),
            const SizedBox(width: 10),
            const Text('Ejercicio 3: MCD de Dos Números'),
          ],
        ),
        backgroundColor: Colors.orange,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            TextField(
              controller: _controller1,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(
                labelText: 'Primer número',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 10),
            TextField(
              controller: _controller2,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(
                labelText: 'Segundo número',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 10),
            ElevatedButton(
              onPressed: _calculateMCD,
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.orange,
                padding: const EdgeInsets.symmetric(vertical: 12.0),
              ),
              child: const Text(
                'Calcular MCD',
                style: TextStyle(color: Colors.white),
              ),
            ),
            const SizedBox(height: 10),
            Text(
              _result,
              style: const TextStyle(fontSize: 16, color: Colors.grey),
              textAlign: TextAlign.center,
            ),
            const Spacer(),
            Align(
              alignment: Alignment.bottomRight,
              child: SizedBox(
                width: 100,
                child: ElevatedButton(
                  onPressed: () {
                    Navigator.pop(context);
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.orange,
                    padding: const EdgeInsets.symmetric(vertical: 8.0),
                  ),
                  child: const Text(
                    'Volver',
                    style: TextStyle(color: Colors.white),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

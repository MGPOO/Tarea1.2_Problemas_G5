import 'package:flutter/material.dart';

class Ejercicio1Screen extends StatefulWidget {
  const Ejercicio1Screen({Key? key}) : super(key: key);

  @override
  _Ejercicio1ScreenState createState() => _Ejercicio1ScreenState();
}

class _Ejercicio1ScreenState extends State<Ejercicio1Screen> {
  List<String> _asciiTable = [];
  List<String> _displayedTable = [];
  int _currentIndex = 0;
  static const int _batchSize = 23;

  @override
  void initState() {
    super.initState();
    _generateAsciiTable();
    _loadNextBatch();
  }

  void _generateAsciiTable() {
    // Mapa de caracteres no imprimibles con abreviaturas
    final Map<int, String> controlCharacters = {
      0: "NULL",
      1: "SOH",
      2: "STX",
      3: "ETX",
      4: "EOT",
      5: "ENQ",
      6: "ACK",
      7: "BEL",
      8: "BS",
      9: "HT",
      10: "LF",
      11: "VT",
      12: "FF",
      13: "CR",
      14: "SO",
      15: "SI",
      16: "DLE",
      17: "DC1",
      18: "DC2",
      19: "DC3",
      20: "DC4",
      21: "NAK",
      22: "SYN",
      23: "ETB",
      24: "CAN",
      25: "EM",
      26: "SUB",
      27: "ESC",
      28: "FS",
      29: "GS",
      30: "RS",
      31: "US",
      127: "DEL",
      160:"á",
    };

    for (int i = 0; i <= 255; i++) {
      String charRepresentation;

      if (controlCharacters.containsKey(i)) {
        charRepresentation = controlCharacters[i]!; // Abreviatura de control
      } else if (i >= 32 && i <= 126 || i >= 160 && i <= 255) {
        charRepresentation = String.fromCharCode(i); // Caracter imprimible
      } else {
        charRepresentation = "<no imprimible>"; // Otros casos
      }

      _asciiTable.add('$i: $charRepresentation');
    }
  }

  void _loadNextBatch() {
    setState(() {
      final int endIndex = (_currentIndex + _batchSize > _asciiTable.length)
          ? _asciiTable.length
          : _currentIndex + _batchSize;
      _displayedTable.addAll(_asciiTable.sublist(_currentIndex, endIndex));
      _currentIndex = endIndex;
    });
  }

  @override
  Widget build(BuildContext context) {
    final bool hasMore = _currentIndex < _asciiTable.length;

    return Scaffold(
      appBar: AppBar(
        title: Row(
          children: [
            const Icon(Icons.table_chart),
            const SizedBox(width: 10),
            const Text('Ejercicio 1: Tabla ASCII Extendida'),
          ],
        ),
        backgroundColor: Colors.blue,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            Expanded(
              child: ListView.builder(
                itemCount: _displayedTable.length,
                itemBuilder: (context, index) {
                  return Text(
                    _displayedTable[index],
                    style: const TextStyle(fontSize: 16),
                  );
                },
              ),
            ),
            if (hasMore)
              ElevatedButton(
                onPressed: _loadNextBatch,
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.blue,
                  padding: const EdgeInsets.symmetric(vertical: 14.0, horizontal: 20.0),
                ),
                child: const Text(
                  'Pulse para continuar',
                  style: TextStyle(color: Colors.white, fontSize: 16),
                ),
              ),
            if (!hasMore)
              const Text(
                'Fin de la tabla ASCII Extendida.',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
              ),
            const SizedBox(height: 10),
            Align(
              alignment: Alignment.bottomRight,
              child: SizedBox(
                width: 100,
                child: ElevatedButton(
                  onPressed: () {
                    Navigator.pop(context);
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.blue,
                    padding: const EdgeInsets.symmetric(vertical: 8.0),
                  ),
                  child: const Text(
                    'Volver',
                    style: TextStyle(color: Colors.white),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

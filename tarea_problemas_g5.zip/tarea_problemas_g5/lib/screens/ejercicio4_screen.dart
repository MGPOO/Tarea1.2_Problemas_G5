import 'package:flutter/material.dart';

class Ejercicio4Screen extends StatefulWidget {
  const Ejercicio4Screen({Key? key}) : super(key: key);

  @override
  _Ejercicio4ScreenState createState() => _Ejercicio4ScreenState();
}

class _Ejercicio4ScreenState extends State<Ejercicio4Screen> {
  final TextEditingController _controller = TextEditingController();
  String _result = '';

  void _factorizeNumber() {
    final int? number = int.tryParse(_controller.text);

    if (number == null || number <= 0) {
      setState(() {
        _result = 'Por favor, ingrese un número entero positivo.';
      });
      return;
    }

    int n = number;
    int factor = 2;
    Map<int, int> factorization = {};

    while (n > 1) {
      int count = 0;
      while (n % factor == 0) {
        n ~/= factor;
        count++;
      }
      if (count > 0) {
        factorization[factor] = count;
      }
      factor++;
    }

    setState(() {
      _result = factorization.entries
          .map((entry) => '${entry.key}^${entry.value}')
          .join(' × ');
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Row(
          children: [
            const Icon(Icons.scatter_plot),
            const SizedBox(width: 10),
            const Text('Ejercicio 4: Factorización'),
          ],
        ),
        backgroundColor: Colors.purple,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            TextField(
              controller: _controller,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(
                labelText: 'Ingrese un número entero',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 10),
            ElevatedButton(
              onPressed: _factorizeNumber,
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.purple,
                padding: const EdgeInsets.symmetric(vertical: 12.0),
              ),
              child: const Text(
                'Calcular',
                style: TextStyle(color: Colors.white),
              ),
            ),
            const SizedBox(height: 10),
            Text(
              _result.isEmpty
                  ? 'Ingrese un número para calcular su factorización.'
                  : 'Factorización: $_result',
              style: const TextStyle(fontSize: 16),
              textAlign: TextAlign.center,
            ),
            const Spacer(),
            Align(
              alignment: Alignment.bottomRight,
              child: SizedBox(
                width: 100, // Botón más pequeño
                child: ElevatedButton(
                  onPressed: () {
                    Navigator.pop(context);
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.purple,
                    padding: const EdgeInsets.symmetric(vertical: 8.0),
                  ),
                  child: const Text(
                    'Volver',
                    style: TextStyle(color: Colors.white),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

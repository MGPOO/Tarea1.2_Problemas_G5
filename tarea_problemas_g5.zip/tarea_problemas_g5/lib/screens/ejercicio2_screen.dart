import 'package:flutter/material.dart';

class Ejercicio2Screen extends StatefulWidget {
  const Ejercicio2Screen({Key? key}) : super(key: key);

  @override
  _Exercise2ScreenState createState() => _Exercise2ScreenState();
}

class _Exercise2ScreenState extends State<Ejercicio2Screen> {
  final TextEditingController _controller = TextEditingController();
  String _result = 'Ingrese un número para calcular su factorial.';

  void _calculateFactorial() {
    final int? number = int.tryParse(_controller.text);
    if (number == null || number < 0) {
      setState(() {
        _result = 'Por favor, ingrese un número válido (positivo).';
      });
      return;
    }
    int factorial = 1;
    for (int i = 1; i <= number; i++) {
      factorial *= i;
    }
    setState(() {
      _result = 'El factorial de $number es $factorial.';
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Row(
          children: [
            const Icon(Icons.calculate),
            const SizedBox(width: 10),
            const Text('Ejercicio 2: Factorial de un Número'),
          ],
        ),
        backgroundColor: Colors.green,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            TextField(
              controller: _controller,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(
                labelText: 'Ingrese un número',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 10),
            ElevatedButton(
              onPressed: _calculateFactorial,
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.green,
                padding: const EdgeInsets.symmetric(vertical: 12.0),
              ),
              child: const Text(
                'Calcular Factorial',
                style: TextStyle(color: Colors.white),
              ),
            ),
            const SizedBox(height: 10),
            Text(
              _result,
              style: const TextStyle(fontSize: 16, color: Colors.grey),
              textAlign: TextAlign.center,
            ),
            const Spacer(),
            Align(
              alignment: Alignment.bottomRight,
              child: SizedBox(
                width: 100,
                child: ElevatedButton(
                  onPressed: () {
                    Navigator.pop(context);
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.green,
                    padding: const EdgeInsets.symmetric(vertical: 8.0),
                  ),
                  child: const Text(
                    'Volver',
                    style: TextStyle(color: Colors.white),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

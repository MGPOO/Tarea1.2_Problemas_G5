import 'package:flutter/material.dart';
import '../screens/ejercicio1_screen.dart';
import '../screens/ejercicio2_screen.dart';
import '../screens/ejercicio3_screen.dart';
import '../screens/ejercicio4_screen.dart';
import '../screens/ejercicio5_screen.dart';

class MainMenu extends StatelessWidget {
  const MainMenu({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Tarea 1.2 Problemas Grupo 5',
          style: TextStyle(color: Colors.white, fontSize: 18),
        ),
        backgroundColor: Colors.indigo,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const SizedBox(height: 20),
            Image.asset(
              '../src/espe.png',
              width: 300, // Ajusta el tamaño según sea necesario
              height: 150,
              fit: BoxFit.contain,
            ),
            const SizedBox(height: 20),
            const Text(
              'Carrera de Ingeniería de Software',
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 16),
            ),
            const Text(
              'Desarrollo de Aplicaciones Móviles',
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 16),
            ),
            const Text(
              'Integrantes: Bedón Alexander, Gutiérrez Miguel, Tobar Dennis',
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 16),
            ),
            const Text(
              'Fecha: 07/12/2024',
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 16),
            ),
            const SizedBox(height: 20),
            _buildMenuButton(
              context,
              'Ejercicio 1: Tabla ASCII',
              Colors.blue,
              Icons.table_chart,
              const Ejercicio1Screen(),
            ),
            const SizedBox(height: 10),
            _buildMenuButton(
              context,
              'Ejercicio 2: Factorial de un número',
              Colors.green,
              Icons.calculate,
              const Ejercicio2Screen(),
            ),
            const SizedBox(height: 10),
            _buildMenuButton(
              context,
              'Ejercicio 3: MCD de dos números',
              Colors.orange,
              Icons.functions,
              const Ejercicio3Screen(),
            ),
            const SizedBox(height: 10),
            _buildMenuButton(
              context,
              'Ejercicio 4: Factorización de un número',
              Colors.purple,
              Icons.scatter_plot,
              const Ejercicio4Screen(),
            ),
            const SizedBox(height: 10),
            _buildMenuButton(
              context,
              'Ejercicio 5: Números Primos',
              Colors.teal,
              Icons.numbers,
              const Ejercicio5Screen(),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildMenuButton(
      BuildContext context,
      String title,
      Color color,
      IconData icon,
      Widget screen,
      ) {
    return ElevatedButton(
      onPressed: () {
        Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => screen),
        );
      },
      style: ElevatedButton.styleFrom(
        backgroundColor: color,
        padding: const EdgeInsets.symmetric(vertical: 16.0, horizontal: 10.0),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(10.0),
        ),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.start,
        children: [
          Icon(icon, color: Colors.white),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              title,
              style: const TextStyle(
                fontSize: 16,
                color: Colors.white, // Letra blanca
              ),
            ),
          ),
        ],
      ),
    );
  }
}
